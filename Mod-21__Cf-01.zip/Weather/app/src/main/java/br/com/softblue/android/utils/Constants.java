package br.com.softblue.android.utils;

// Constantes gerais da aplicação
public class Constants {

	// Tag para uso do log
	public static final String LOG_TAG = "WeatherApp";
}
