package br.com.softblue.exercicio;

import android.app.ListActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

public class ItemListActivity extends ListActivity implements ActionMode.Callback, ItemDialog.ItemListener {

	// Adapter para o ListView
	private ItemAdapter adapter;
	
	// Indica a posição do item selecionado
	private int selectedItem;
	
	// Indica o nome do item selecionado
	private String selectedItemName;
	
	// Indica se está em modo de inserção de item (true) ou atualização (false)
	private boolean insertMode;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Inicia o gerenciador de itens da lista
		adapter = new ItemAdapter(this);

		// Atribui o adapter à activity
		setListAdapter(adapter);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.item_list, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();

		if (id == R.id.action_new) {
			// Exibe caixa de diálogo para inserção de item
			ItemDialog dialog = new ItemDialog();
			dialog.show(getFragmentManager(), "itemDialog");
			
			// Habilita modo de inserção
			insertMode = true;
			
			return true;

		} else {
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void onItem(String name) {
		// Chamado quando ocorre alteração ou inserção de item.
		// Dependendo do insertMode, altera ou insere.
		
		if (insertMode) {
			adapter.insertItem(name);
		} else {
			adapter.updateItem(selectedItem, name);
		}
	}

	@Override
	public boolean onCreateActionMode(ActionMode mode, Menu menu) {
		// Exibe o menu de opções do action mode
		getMenuInflater().inflate(R.menu.context, menu);
		return true;
	}

	@Override
	public void onDestroyActionMode(ActionMode mode) {
		// Remove a cor de fundo da view que havia sido mudada
		View view = getListView().getChildAt(selectedItem);
		view.setBackgroundColor(Color.TRANSPARENT);
	}
	
	@Override
	public boolean onActionItemClicked(ActionMode mode, MenuItem menuItem) {
		int id = menuItem.getItemId();
		
		// Se o botão de exclusão for clicado
		if (id == R.id.action_delete) {
			// Remove o item do adapter
			adapter.removeItem(selectedItem);
			
			// Termina o action mode
			mode.finish();
			return true;
			
		// Se o botão de edição for clicado
		} else if (id == R.id.action_edit) {
			// Exibe a caixa de diálogo
			ItemDialog dialog = new ItemDialog();
			
			// Solicita a exibição do nome atual do item
			dialog.setItem(selectedItemName);
			
			dialog.show(getFragmentManager(), "itemDialog");
			
			// Habilita modo de alteração
			insertMode = false;
			
			// Termina o action mode
			mode.finish();
			
			return true;
		
		} else {
			return false;
		}
	}

	@Override
	public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
		return false;
	}
	
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// Quando um item é clicado, marca a sua posição e seu nome
		selectedItem = position;
		selectedItemName = adapter.getItem(position);
		
		// Troca a cor de fundo da view
		v.setBackgroundColor(Color.LTGRAY);
		
		// Inicia o action mode
		startActionMode(this);
	}
}
