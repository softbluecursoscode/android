package br.com.softblue.exercicio;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ItemAdapter extends BaseAdapter {
	
	private List<String> items = new ArrayList<>();
	private LayoutInflater inflater;
	
	public ItemAdapter(Context context) {
		// Inicializa o LayoutInflater por conveniência
		this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		return items.size();
	}

	@Override
	public String getItem(int pos) {
		return items.get(pos);
	}
	
	public void removeItem(int pos) {
		items.remove(pos);
		
		// Avisa o ListView que os dados do adapter mudaram
		notifyDataSetChanged();
	}
	
	public void updateItem(int pos, String item) {
		items.set(pos, item);
		
		// Avisa o ListView que os dados do adapter mudaram
		notifyDataSetChanged();
	}
	
	public int insertItem(String item) {
		items.add(item);
		
		// Avisa o ListView que os dados do adapter mudaram
		notifyDataSetChanged();
		
		return items.size() - 1;
	}

	@Override
	public long getItemId(int pos) {
		return pos;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// O view holder é um padrão para otimizar o uso de views
		ViewHolder viewHolder;
		
		if (convertView == null) {
			// Obtém o layout
			convertView = inflater.inflate(R.layout.listview, parent, false);
			
			// Cria um view holder e associa à view obtida
			viewHolder = new ViewHolder();
			viewHolder.text = convertView.findViewById(R.id.text);
			convertView.setTag(viewHolder);
			
		} else {
			// Lê o view holder da view, para evitar chamadas desnecessárias a findViewById()
			viewHolder = (ViewHolder) convertView.getTag(); 
		}
		
		// Exibe o texto no TextView
		viewHolder.text.setText(items.get(position));
		
		return convertView;
	}
	
	/**
	 * Classe para armazenar os dados da view
	 */
	private static class ViewHolder {
		TextView text;
	}
}
