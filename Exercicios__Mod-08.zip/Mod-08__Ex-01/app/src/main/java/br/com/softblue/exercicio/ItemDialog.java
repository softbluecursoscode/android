package br.com.softblue.exercicio;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

/**
 * Caixa de diálogo para inserir ou alterar um item
 */
public class ItemDialog extends DialogFragment implements DialogInterface.OnClickListener {
	
	private ItemListener listener;
	private EditText edtName;
	private String item;
	
	@Override
	public void onAttach(Context context) {
		super.onAttach(context);
	
		// A activity deve implementar ItemListener
		if (!(context instanceof ItemListener)) {
			throw new IllegalArgumentException("A activity deve implementar ItemDialog.ItemListener");
		}
		
		this.listener = (ItemListener) context;
	}
	
	public void setItem(String item) {
		this.item = item;
	}

	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		// Cria o dialog com a view customizada
		
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		
		builder.setTitle(R.string.item);
		builder.setPositiveButton(R.string.ok, this);
		builder.setNegativeButton(R.string.cancelar, this);

		View view = View.inflate(getActivity(), R.layout.dialog, null);
		builder.setView(view);
		
		this.edtName = view.findViewById(R.id.edt_name);
		
		if (item != null) {
			// Se um nome foi especificado (no caso de alteração, por exemplo), mostra este nome
			edtName.setText(item);
		}
		
		return builder.create();
	}
	
	@Override
	public void onClick(DialogInterface dialog, int which) {
		if (which == DialogInterface.BUTTON_POSITIVE) {
			// Se for digitado um item, chama o listener para avisar a activity
			
			String name = edtName.getText().toString();
			
			if (!TextUtils.isEmpty(name)) {
				listener.onItem(name);
			}
		}
	}
	
	/**
	 * Interface implementada pela activity. Utilizada para comunicar a activity sobre o nome
	 * do item digitado.
	 */
	public interface ItemListener {
		void onItem(String name);
	}
}
