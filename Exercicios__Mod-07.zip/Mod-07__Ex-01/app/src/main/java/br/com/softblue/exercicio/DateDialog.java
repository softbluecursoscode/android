package br.com.softblue.exercicio;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.os.Bundle;

import java.util.Calendar;

/**
 * Dialog para abrir o TimePicker
 */
public class DateDialog extends DialogFragment {
	
	// Listener a ser chamado quando uma hora for definida
	private DatePickerDialog.OnDateSetListener listener;
 
	@Override
	public void onAttach(Context context) {
		super.onAttach(context);
		
		// A activity que contém o fragment deve implementar a interface OnDateSetListener.
		// Caso isto não ocorra, uma exceção é lançada.
		if (!(context instanceof DatePickerDialog.OnDateSetListener)) {
			throw new IllegalArgumentException("Activity deve implementar DatePickerDialog.OnDateSetListener");
		}
		
		this.listener = (DatePickerDialog.OnDateSetListener) context;
	}
	
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		
		// Obtém um calendar que representa o momento atual
		Calendar now = Calendar.getInstance();
		
		// Lê o ano, o mês e o dia
		int year = now.get(Calendar.YEAR);
		int monthOfYear = now.get(Calendar.MONTH);
		int dayOfMonth = now.get(Calendar.DAY_OF_MONTH);
		
		// Retorna um DatePickerDialog com a data atual.
		// A activity é o listener, portanto ela será chamada quando um valor for definido.
		return new DatePickerDialog(getActivity(), listener, year, monthOfYear, dayOfMonth);
		
	}
}
