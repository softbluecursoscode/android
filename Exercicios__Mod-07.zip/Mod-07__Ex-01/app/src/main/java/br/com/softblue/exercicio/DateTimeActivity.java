package br.com.softblue.exercicio;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.FragmentManager;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

public class DateTimeActivity extends Activity implements TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener {

	// Formatador de data no padrão especificado
	private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("pt", "BR"));
	
	// Calendar para representar a data/hora
	private Calendar calendar;
	
	private TextView txtDateTime;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Define o layout da tela
		setContentView(R.layout.activity_date_time);

		// Obtém as referências ao texto exibido na interface
		txtDateTime = findViewById(R.id.txt_datetime);
	
		// Inicializa o Calendar com a data/hora corrente do sistema
		calendar = Calendar.getInstance();
		
		// Atualiza o texto exibido
		updateText();
	}

	public void definirData(View v) {
		// Definição da data
		DateDialog dialog = new DateDialog();
		FragmentManager fm = getFragmentManager();
		dialog.show(fm, "dateDialog");
	}
	
	public void definirHora(View v) {
		// Definição da hora
		TimeDialog dialog = new TimeDialog();
		FragmentManager fm = getFragmentManager();
		dialog.show(fm, "timeDialog");
	}

	/**
	 * Este método é chamado quando um valor é definido no TimePicker
	 */
	@Override
	public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
		// Atualiza a hora e o minuto do Calendar
		calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
		calendar.set(Calendar.MINUTE, minute);
		
		// Atualiza o texto exibido na tela
		updateText();
	}

	/**
	 * Este m�todo � chamado quando um valor � definido no DatePicker
	 */
	@Override
	public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
		// Atualiza o ano, o mês e o dia do Calendar
		calendar.set(Calendar.YEAR, year);
		calendar.set(Calendar.MONTH, month);
		calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
		
		// Atualiza o texto exibido na tela
		updateText();
	}
	
	/**
	 * Atualiza o texto exibido na tela
	 */
	private void updateText() {
		// Formata a data/hora
		String formattedDate = FORMATTER.format(calendar.getTime());
		
		// Altera o texto na view
		txtDateTime.setText(formattedDate);
	}
}
