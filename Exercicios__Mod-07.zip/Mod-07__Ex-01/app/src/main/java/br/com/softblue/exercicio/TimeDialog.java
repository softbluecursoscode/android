package br.com.softblue.exercicio;

import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;

import java.util.Calendar;

/**
 * Dialog para abrir o TimePicker
 */
public class TimeDialog extends DialogFragment {
	
	// Listener a ser chamado quando uma hora for definida
	private TimePickerDialog.OnTimeSetListener listener;
 
	@Override
	public void onAttach(Context context) {
		super.onAttach(context);
		
		// A activity que contém o fragment deve implementar a interface OnTimeSetListener.
		// Caso isto não ocorra, uma exceção é lançada.
		if (!(context instanceof TimePickerDialog.OnTimeSetListener)) {
			throw new IllegalArgumentException("Activity deve implementar TimePickerDialog.OnTimeSetListener");
		}
		
		this.listener = (TimePickerDialog.OnTimeSetListener) context;
	}
	
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		
		// Obtém um calendar que representa o momento atual
		Calendar now = Calendar.getInstance();
		
		// Lê a hora e minuto
		int hourOfDay = now.get(Calendar.HOUR_OF_DAY);
		int minute = now.get(Calendar.MINUTE);
		
		// Retorna um TimePickerDialog com a hora e minuto atuais definidos.
		// A activity é o listener, portanto ela será chamada quando um valor for definido.
		return new TimePickerDialog(getActivity(), listener, hourOfDay, minute, true);
	}
}
