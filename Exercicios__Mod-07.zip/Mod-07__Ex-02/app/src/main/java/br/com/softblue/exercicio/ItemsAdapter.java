package br.com.softblue.exercicio;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

// Adapter customizado
public class ItemsAdapter extends BaseAdapter implements View.OnClickListener {

	// Lista de itens
	private List<Integer> items = new ArrayList<>();
	
	private Context context;
	private LayoutInflater inflater;

	public ItemsAdapter(Context context) {
		this.context = context;
		this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}
	
	public void putNumbers(int min, int max) {
		// Adiciona os números na lista de acordo com o intervalo fornecido
		for (int i = min; i <= max; i++) {
			items.add(i);
		}
	}

	@Override
	public int getCount() {
		return items.size();
	}

	@Override
	public Object getItem(int position) {
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		return -1;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// Implementação do padrão view holder para acelerar a renderizaçã da view
		
		View view = convertView;
		ViewHolder holder;

		if (view == null) {
			view = inflater.inflate(R.layout.item, parent, false);
			holder = new ViewHolder();
			holder.number = view.findViewById(R.id.txt_number);
			holder.button = view.findViewById(R.id.btn_info);
			holder.button.setOnClickListener(this);
			view.setTag(holder);
		
		} else {
			holder = (ViewHolder) view.getTag();
		}

		String number = String.valueOf(items.get(position));
		holder.number.setText(number);
		
		// Associa o número ao botão. Esta informação é recuperada na hora do clique
		holder.button.setTag(number);
		
		return view;
	}

	// Classe para representar o view holder
	private static class ViewHolder {
		public TextView number;
		public Button button;
	}

	@Override
	public void onClick(View view) {
		// Lê o número associado ao botão clicado
		String number = (String) view.getTag();
		
		// Mostra o toast
		Toast.makeText(context, "Você clicou no número " + number, Toast.LENGTH_SHORT).show();
	}
}
