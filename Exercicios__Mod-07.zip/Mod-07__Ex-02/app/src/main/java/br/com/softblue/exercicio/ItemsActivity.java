package br.com.softblue.exercicio;

import android.app.ListActivity;
import android.os.Bundle;

public class ItemsActivity extends ListActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Cria o adapter que vai preencher a lista
		ItemsAdapter adapter = new ItemsAdapter(this);
		
		// Adiciona o intervalo de 1 a 50 no adapter
		adapter.putNumbers(1, 50);
		
		// Define o adapter para a lista
		setListAdapter(adapter);
	}
}
