package br.com.softblue.android;

import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v14.preference.SwitchPreference;
import android.support.v7.preference.CheckBoxPreference;
import android.support.v7.preference.ListPreference;
import android.support.v7.preference.PreferenceFragmentCompat;
import android.support.v7.preference.PreferenceManager;

public class ConfigFragment extends PreferenceFragmentCompat implements SharedPreferences.OnSharedPreferenceChangeListener {

    private SwitchPreference prefMapsEnabled;
    private ListPreference prefUnit;
    private CheckBoxPreference prefSattelite;

    private Resources res;

    @Override
    public void onCreatePreferences(Bundle bundle, String s) {
        setPreferencesFromResource(R.xml.config, s);

        res = getActivity().getResources();

        prefMapsEnabled = (SwitchPreference) findPreference(res.getString(R.string.pref_map_enabled));
        prefUnit = (ListPreference) findPreference(res.getString(R.string.pref_un_dist));
        prefSattelite = (CheckBoxPreference) findPreference(res.getString(R.string.pref_sattelite));

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        prefs.registerOnSharedPreferenceChangeListener(this);

        boolean defValue = res.getBoolean(R.bool.map_enabled_default);
        boolean enabled = prefs.getBoolean(res.getString(R.string.pref_map_enabled), defValue);

        setEnabled(enabled);
    }

    private void setEnabled(boolean enabled) {
        prefUnit.setEnabled(enabled);
        prefSattelite.setEnabled(enabled);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

        if (key.equals(prefMapsEnabled.getKey())) {
            boolean defValue = res.getBoolean(R.bool.map_enabled_default);
            boolean enabled = sharedPreferences.getBoolean(key, defValue);
            setEnabled(enabled);
        }
    }
}
