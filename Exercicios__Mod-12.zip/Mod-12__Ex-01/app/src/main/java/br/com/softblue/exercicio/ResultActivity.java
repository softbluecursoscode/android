package br.com.softblue.exercicio;


import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Locale;

public class ResultActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_result);
		
		TextView txtResult = findViewById(R.id.txt_result);
		
		// Extrai o valor de PI da intent
		double pi = getIntent().getDoubleExtra("pi", -1);
		
		txtResult.setText(String.format(new Locale("pt", "BR"), "O valor de PI é %f", pi));
	}
}
