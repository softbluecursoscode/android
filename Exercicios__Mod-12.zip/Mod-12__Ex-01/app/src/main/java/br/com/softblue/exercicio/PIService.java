package br.com.softblue.exercicio;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

public class PIService extends Service {
	
	private static final int NOTIFICATION_ID = 100;

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		
		// Cria uma nova thread para fazer o cálculo
		new Thread(new Runnable() {			
			@Override
			public void run() {
				// Calcula o valor de PI
				double soma = 0;
				for (int k = 1; k <= 1000000; k++) {
					soma += (Math.pow(-1, k + 1)) / (2 * k - 1);
				}
				
				double pi = soma * 4;
				
				// Envia uma notificação sobre o resultado
				sendNotification(pi);
			}
		}).start();
		
		return Service.START_STICKY;
	}
	
	private void sendNotification(double pi) {
		Notification.Builder builder = new Notification.Builder(this, NotificationUtils.getChannelId(this));
		builder.setContentTitle("PI calculado");
		builder.setContentText("Clique para ver o resultado");
		builder.setSmallIcon(R.drawable.ic_notify);
		builder.setAutoCancel(true);
		
		// Cria uma pending intent que abre uma activity quando a notificação é clicada
		Intent intent = new Intent(getApplicationContext(), ResultActivity.class);
		intent.putExtra("pi", pi);
		PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
		builder.setContentIntent(pendingIntent);
		
		// Envia a notificação
		NotificationManager nm = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
		if (nm != null) {
			nm.notify(NOTIFICATION_ID, builder.build());
		}
	}
	
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
}
