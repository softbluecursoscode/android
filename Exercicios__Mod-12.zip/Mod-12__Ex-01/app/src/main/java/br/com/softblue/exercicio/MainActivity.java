package br.com.softblue.exercicio;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
	
	private Button btnCalc; 

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);
		
		btnCalc = findViewById(R.id.btn_calcular);
	}

	public void calcular(View v) {
		// Inicia o serviço de cálculo do PI
		Intent intent = new Intent(this, PIService.class);
		startService(intent);
		
		// Desabilita o botão
		btnCalc.setEnabled(false);
	}
}
