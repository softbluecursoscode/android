package br.com.softblue.exercicio;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements ServiceConnection {
	
	// Service
	private RandomService service;
	
	// Flag indicando se existe conexão ao service
	private boolean bound;
	
	private TextView txtValue;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);
		
		txtValue = findViewById(R.id.txt_value);
	}
	
	@Override
	protected void onStart() {
		super.onStart();
		
		// Se conecta ao service. Cria o service caso ele não exista (neste caso não vai existir)
		Intent intent = new Intent(this, RandomService.class);
		bindService(intent, this, BIND_AUTO_CREATE);
	}

	@Override
	protected void onStop() {
		super.onStop();
		
		// Desconect do service
		unbindService(this);
		bound = false;
	}
	
	public void read(View view) {
		if (bound) {
			// Lê o valor gerado pelo service e exibe na tela
			double value = service.getValue();
			txtValue.setText(String.valueOf(value));
		}
	}
	
	@Override
	public void onServiceConnected(ComponentName name, IBinder service) {
		// Com a conexão ao serviço estabelecida, armazena a referência ao RandomService
		RandomService.RandomServiceBinder binder = (RandomService.RandomServiceBinder) service;
		this.service = binder.getService();
		bound = true;
		Toast.makeText(this, "Conectado ao serviço", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onServiceDisconnected(ComponentName name) {
	}
}
