package br.com.softblue.exercicio;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;

public class RandomService extends Service {

	// Binder do serviço
	private RandomServiceBinder binder = new RandomServiceBinder();

	// Último valor gerado
	private double value;
	
	// Flag para controlar se a geração está executando ou não. O modificador volatile é usado para evitar
	// que as threads façam cache do valor, causando problemas de concorrência (isto é algo inerente à linguagem Java.
	// Pesquise mais informações à respeito caso tenha interesse).
	private volatile boolean running;

	// Chamado na conexão ao serviço
	@Override
	public IBinder onBind(Intent intent) {
		running = true;

		// Inicia thread para executar o service
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (running) {
					// Gera um número randômico e armazena em value
					setValue(Math.random());
					SystemClock.sleep(1000);
				}

			}
		}).start();

		return binder;
	}

	// Chamado na desconexão do serviço
	@Override
	public boolean onUnbind(Intent intent) {
		running = false;
		return false;
	}

	// Define um valor. O synchronized é usado porque este método é chamado por 2 threads.
	private synchronized void setValue(double value) {
		this.value = value;
		Log.d("RandomService", "Valor: " + value);

	}

	// Retorna um valor. O synchronized é usado porque este método é chamado por 2 threads.
	public synchronized double getValue() {
		return value;
	}

	// Classe que representa o binder ao serviço
	public class RandomServiceBinder extends Binder {
		public RandomService getService() {
			return RandomService.this;
		}
	}
}
