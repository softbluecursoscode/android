package br.com.softblue.exercicio;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

// Adapter da lista
public class RSSAdapter extends BaseAdapter {

	private static final DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);

	private List<Feed> feeds = new ArrayList<>();
	private LayoutInflater inflater;

	public RSSAdapter(Context context) {
		this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		return feeds.size();
	}

	@Override
	public Feed getItem(int position) {
		return feeds.get(position);
	}

	@Override
	public long getItemId(int position) {
		return -1;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view = convertView;
		ViewHolder holder;

		if (view == null) {
			view = inflater.inflate(R.layout.adapter_list, parent, false);
			holder = new ViewHolder();
			holder.txtTitle = view.findViewById(R.id.txt_title);
			holder.txtDate = view.findViewById(R.id.txt_date);
			view.setTag(holder);

		} else {
			holder = (ViewHolder) view.getTag();
		}

		Feed feed = feeds.get(position);

		holder.txtTitle.setText(feed.getTitle());
		holder.txtDate.setText(df.format(feed.getDate()));
		return view;
	}

	public void addAll(List<Feed> feeds) {
		this.feeds.clear();
		this.feeds.addAll(feeds);
		notifyDataSetChanged();
	}

	private static class ViewHolder {
		private TextView txtTitle;
		private TextView txtDate;
	}
}
