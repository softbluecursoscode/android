package br.com.softblue.exercicio;

import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.xmlpull.v1.XmlPullParser;

import android.util.Xml;

import br.com.softblue.exercicio.http.HttpCall;
import br.com.softblue.exercicio.http.HttpResponse;

// Leitor de feeds RSS
public class RSSReader {

	// Formatador de data (usado no feed)
	private static final DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US);

	// URL do RSS
	private String url;

	public RSSReader(String url) {
		this.url = url;
	}

	// Obtém a lista de feeds
	public List<Feed> readFeeds() throws Exception {
		List<Feed> feeds = new ArrayList<>();

		// Executa uma operação GET na URL
		HttpCall http = new HttpCall(url);
		HttpResponse response = http.execute(HttpCall.Method.GET);

		// Obtém o XML de resposta
		String xml = response.extractDataAsString();

		// Inicia o parse do XML usando um XmlPullParser
		XmlPullParser parser = Xml.newPullParser();
		parser.setInput(new StringReader(xml));

		int eventType;
		Feed feed = null;

		// Enquanto o documento não terminar, faz o parse
		while ((eventType = parser.next()) != XmlPullParser.END_DOCUMENT) {
			if (eventType == XmlPullParser.START_TAG && parser.getName().equals("item")) {
				// Cria o objeto do feed quando uma tag 'item' é aberta
				feed = new Feed();

			} else if (eventType == XmlPullParser.START_TAG && parser.getName().equals("title") && feed != null) {
				// Se for a tag 'title' do item, define o valor no objeto
				parser.next();
				feed.setTitle(parser.getText());

			} else if (eventType == XmlPullParser.START_TAG && parser.getName().equals("link") && feed != null) {
				// Se for a tag 'link' do item, define o valor no objeto
				parser.next();
				feed.setLink(parser.getText());
			
			} else if (eventType == XmlPullParser.START_TAG && parser.getName().equals("pubDate") && feed != null) {
				// Se for a tag 'pubDate' do item, define o valor no objeto
				parser.next();
				feed.setDate(df.parse(parser.getText()));
			
			} else if (eventType == XmlPullParser.END_TAG && parser.getName().equals("item")) {
				// Se a tag 'item' foi fechada, coloca o objeto criado na lista
				feeds.add(feed);
				feed = null;
			}
		}

		return feeds;
	}
}
