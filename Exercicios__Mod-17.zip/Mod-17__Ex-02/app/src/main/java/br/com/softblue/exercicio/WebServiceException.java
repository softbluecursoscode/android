package br.com.softblue.exercicio;

// Classe que representa uma exceção na chamada ao web service
@SuppressWarnings("serial")
public class WebServiceException extends Exception {

	public WebServiceException(Throwable throwable) {
		super(throwable);
	}
}
