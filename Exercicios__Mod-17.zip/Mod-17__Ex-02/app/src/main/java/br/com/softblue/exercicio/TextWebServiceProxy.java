package br.com.softblue.exercicio;

import android.annotation.SuppressLint;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

// Classe que encapsula o acesso ao web service
public class TextWebServiceProxy {

	private static final String ENDPOINT = "http://www2.softblue.com.br/web/services/TextWS";
	
	// Conta os caracteres de um texto. O retorno é uma String no formato JSON
	@SuppressLint("DefaultLocale")
	public String countChars(String texto) throws WebServiceException {
		try {
			SoapObject soap = new SoapObject("http://examples.softblue.com.br", "countChars");
			soap.addProperty("texto", texto.toUpperCase());
			
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.setOutputSoapObject(soap);
			
			HttpTransportSE transport = new HttpTransportSE(ENDPOINT);
			transport.call("", envelope);
			
			Object response = envelope.getResponse();
			return response.toString();
		
		} catch (IOException | XmlPullParserException e) {
			throw new WebServiceException(e);
		}
	}
}
