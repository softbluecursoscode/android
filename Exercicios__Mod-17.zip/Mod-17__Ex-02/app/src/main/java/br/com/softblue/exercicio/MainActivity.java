package br.com.softblue.exercicio;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	private EditText edtText;
	private TextView txtResult;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_main);
		
		edtText = findViewById(R.id.edt_text);
		txtResult = findViewById(R.id.txt_result);
	}
	
	public void processar(View v) {
		String texto = edtText.getText().toString();
		
		if (!TextUtils.isEmpty(texto)) {
			// Inicia a task que chama o web service
			new CallWebServiceTask().execute(texto);
		}
	}

	private class CallWebServiceTask extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			try {
				// Chama o web service
				TextWebServiceProxy proxy = new TextWebServiceProxy();
				String jsonStr = proxy.countChars(params[0]);
				
				StringBuilder sb = new StringBuilder();
				
				// O retorno do web service é um array JSON. Dentro do array existem objetos JSON, e cada objeto
				// tem apenas um par de chave e valor: a chave é o caractere (String) e o valor é a contagem do
				// caractere (int)
				
				JSONArray array = new JSONArray(jsonStr);
				for (int i = 0; i < array.length(); i++) {
					JSONObject jsonObj = array.getJSONObject(i);
					
					// Extrai o caractere e a contagem
					String c = jsonObj.keys().next();
					int count = jsonObj.getInt(c);
					
					sb.append(c).append(" => ").append(count).append("\n");
				}
				
				return sb.toString();
				
			} catch (JSONException | WebServiceException e) {
				e.printStackTrace();
				return null;
			}
		}

		@Override
		protected void onPostExecute(String result) {
			txtResult.setText(result);
		}
	}
}
