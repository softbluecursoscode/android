package br.com.softblue.exercicio;

import android.Manifest;
import android.widget.Toast;

import java.util.List;

import br.com.softblue.exercicio.permission.PermissionActivity;
import br.com.softblue.exercicio.permission.PermissionDialog;


public class MainActivity extends PermissionActivity implements PermissionDialog.OnPermissionDialogListener {

    @Override
    protected void onStart() {
        super.onStart();

        // Solicita a permissão para processar o telefonema realizado
        enablePermissions(0, true, Manifest.permission.PROCESS_OUTGOING_CALLS);
    }

    @Override
    protected void onPermissionsNeeded(int requestPermissionId, List<String> permissions) {
        showPermissionDialog(0, "Sem esta permissão, o aplicativo não funciona. Você concede a permissão?");
    }

    @Override
    protected void onPermissionsDenied(int requestPermissionId, List<String> permissions) {
        Toast.makeText(this, "Desculpe, mas não posso seguir em frente sem a permissão...", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPermissionsGranted(int requestPermissionId, List<String> permissions) throws SecurityException {
        Toast.makeText(this, "Permissão concedida! Pode continuar.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPermissionDialogResult(int dialogId, boolean accepted) {
        if (accepted) {
            enablePermissions(0, false, Manifest.permission.PROCESS_OUTGOING_CALLS);
        }
    }
}
