package br.com.softblue.exercicio;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/*
 * O Android envia um broadcast do tipo NEW_OUTGOING_CALL quando uma chamada está prestes a ser realizada.
 * Este broadcast é ordenado, portanto aplicações podem alterar o número de telefone antes que o Android
 * realize a discagem.
 * É preciso declarar a permissão PROCESS_OUTGOING_CALLS para que a intent possa ser recebida.
 * Para maiores informações sobre este processo, consulte:
 * http://developer.android.com/reference/android/content/Intent.html#ACTION_NEW_OUTGOING_CALL
 */
public class CallProcessor extends BroadcastReceiver {

	//Prefixo a ser adicionado ao telefone
	private static final String PREFIXO = "00";
	
	@Override
	public void onReceive(Context context, Intent intent) {
		if (intent.getAction() == null || !intent.getAction().equals("android.intent.action.NEW_OUTGOING_CALL")) {
			return;
		}

		//Obtém os extras da intent que disparou o broadcast receiver
		Bundle intentExtras = intent.getExtras();
		
		//Obtém o número de telefone discado pelo usuário
		String telefone = intentExtras.getString(Intent.EXTRA_PHONE_NUMBER);
		
		//Se o telefone já começa com o prefixo, ignora
		if (telefone != null && !telefone.startsWith(PREFIXO)) {
			//Adiciona o prefixo no início do número do telefone
			String novoTelefone = PREFIXO + telefone;
			
			//Define o novo número a ser discado (que fica dentro de resultData, de acordo
			//com a documentação do Android)
			setResultData(novoTelefone);
		}
	}
}