package br.com.softblue.exercicio;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class AirplaneModeReceiver extends BroadcastReceiver {

	// Tag para agrupar as mensagens de log
	private static final String TAG = "Airplane";

	@Override
	public void onReceive(Context context, Intent intent) {
		// Lê o estado do modo avião. 'true' indica ligado e 'false' desligado
		boolean on = intent.getBooleanExtra("state", false);

		// Com base no estado do do modo avião, mostra a mensagem de log
		if (on) {
			Toast.makeText(context, "Modo avião ligado!", Toast.LENGTH_LONG).show();
			Log.i(TAG, "Modo avião ligado!");
		} else {
			Toast.makeText(context, "Modo avião desligado!", Toast.LENGTH_LONG).show();
			Log.i(TAG, "Modo avião desligado!");
		}
	}
}