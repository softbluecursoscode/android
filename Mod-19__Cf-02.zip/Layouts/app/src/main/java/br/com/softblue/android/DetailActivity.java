package br.com.softblue.android;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Regiao regiao = (Regiao) getIntent().getSerializableExtra("regiao");

        if (getResources().getBoolean(R.bool.dualPane)) {
            Intent intent = new Intent();
            intent.putExtra("regiao", regiao);
            setResult(RESULT_OK, intent);
            finish();
            return;
        }

        DetailFragment fragment = DetailFragment.newInstance(regiao);
        getSupportFragmentManager().beginTransaction().add(android.R.id.content, fragment, "detail").commit();
    }
}
