package br.com.softblue.android;

public final class Constants {
	
	public enum Type {
		INTERNAL, EXTERNAL
	}
	
	public static final String STORAGE_TYPE = "storage_type";
	
	public static final String FILE_NAME = "texto.txt";
}
