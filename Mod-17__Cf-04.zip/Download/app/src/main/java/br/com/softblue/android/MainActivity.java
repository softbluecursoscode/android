package br.com.softblue.android;

import android.app.Activity;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.io.IOException;
import java.io.InputStream;

import br.com.softblue.android.http.HttpCall;
import br.com.softblue.android.http.HttpResponse;

public class MainActivity extends Activity {

    private static final String IMG_PATH = "http://www.softblue.com.br/public/images/sbv2_logotipo.png";

    private ImageView image;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        image = findViewById(R.id.image);
        progress = findViewById(R.id.progress);
    }

    public void download(View view) {
        DownloadTask task = new DownloadTask();
        task.execute(IMG_PATH);
    }

    private class DownloadTask extends AsyncTask<String, Void, Drawable> {
        @Override
        protected void onPreExecute() {
            image.setVisibility(View.GONE);
            progress.setVisibility(View.VISIBLE);
        }

        @Override
        protected Drawable doInBackground(String... params) {
            String url = params[0];

            try {
                HttpCall httpCall = new HttpCall(url);
                HttpResponse response = httpCall.execute(HttpCall.Method.GET);

                try (InputStream in = response.getInputStream()) {
                    return BitmapDrawable.createFromStream(in, null);
                }

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(Drawable result) {
            image.setImageDrawable(result);
            image.setVisibility(View.VISIBLE);
            progress.setVisibility(View.GONE);
        }
    }
}