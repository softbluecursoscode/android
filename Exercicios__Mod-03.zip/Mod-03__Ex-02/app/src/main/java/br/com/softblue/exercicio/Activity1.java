package br.com.softblue.exercicio;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Activity1 extends Activity implements OnClickListener {
	
	//Define uma constante para um request code
	private static final int REQUEST_CODE = 10;
	
	private Button botao;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		//Cria o botão e define o texto dele como '1' (o nosso "contador" vai começar em 1)
		botao = new Button(this);
		botao.setText("1");
		botao.setOnClickListener(this);
		setContentView(botao);
	}

	@Override
	public void onClick(View v) {
		//Quando o botão é clicado, lê o texto do botão e incrementa o valor em 1
		int contador = Integer.parseInt(botao.getText().toString());
		contador++;
		
		//Cria um bundle e coloca o novo valor do contador dentro dele
		Bundle b = new Bundle();
		b.putInt("cont", contador);
		
		//Cria uma intent, usada para chamar Activity2, e fornece o 
		//bundle como parâmetro (que contém o novo valor do contador)
		Intent i = new Intent(this, Activity2.class);
		i.putExtras(b);
		
		//Chama a Activity2 e aguarda o término dela
		startActivityForResult(i, REQUEST_CODE);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		//Este método será chamado quando a Activity2 terminar
		
		//Checa o request code e o resultado fornecido antes de continuar
		if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
			//Obtém o bundle relacionado à intent enviada pela Activity2 e extrai o valor
			//atual do contador
			Bundle b = data.getExtras();
			int contador = b.getInt("cont");
			
			//Define o valor do contador como o novo texto do botão
			botao.setText(String.valueOf(contador));
		}
	}
}
