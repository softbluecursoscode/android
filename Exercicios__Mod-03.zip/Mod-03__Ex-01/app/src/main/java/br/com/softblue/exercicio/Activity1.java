package br.com.softblue.exercicio;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Activity1 extends Activity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		//Cria o botão
		Button botao = new Button(this);
		
		//Define o texto com base em um resource
		botao.setText(R.string.carregar_activity);
		
		//Adiciona o listener que será chamado em caso de clique no botão
		botao.setOnClickListener(this);
		
		//Define o botão como layout da activity
		setContentView(botao);
	}

	@Override
	public void onClick(View v) {
		//Quando o botão é clicado, cria uma intent
		Intent i = new Intent(this, Activity2.class);
		
		//Invoca a Activity2
		startActivity(i);
	}
}
