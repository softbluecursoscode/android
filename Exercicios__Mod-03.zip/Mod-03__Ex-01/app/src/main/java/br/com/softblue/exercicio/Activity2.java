package br.com.softblue.exercicio;


import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;

public class Activity2 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		//Cria um ImageView, usado para exibir uma imagem
		ImageView image = new ImageView(this);
		
		//Define qual imagem será exibida com base em um drawable resource
		image.setImageResource(R.drawable.android);
		
		//Define o ImageView como a view da activity
		setContentView(image);
	}
}
