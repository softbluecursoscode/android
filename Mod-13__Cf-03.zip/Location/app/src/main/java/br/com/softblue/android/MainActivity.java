package br.com.softblue.android;

import android.Manifest;
import android.location.Location;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.List;

import br.com.softblue.android.location.MockManager;
import br.com.softblue.android.play.GooglePlayActivity;

public class MainActivity extends GooglePlayActivity {

    private static final int PERMISSION_ID = 1;

    private TextView txtLatitude;
    private TextView txtLongitude;

    private MockManager mockManager;
    private LocationRequest request;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtLatitude = findViewById(R.id.txt_latitude);
        txtLongitude = findViewById(R.id.txt_longitude);

        mockManager = new MockManager(this);
    }

    @Override
    protected void onStop() {
        if (mockManager != null) {
            mockManager.dispose();
        }
        super.onStop();
    }

    @Override
    protected void onGooglePlayServicesConnected() {

        request = LocationRequest.create();
        request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        request.setInterval(2000);
        request.setFastestInterval(1000);

        Toast.makeText(this, "Conectado!", Toast.LENGTH_LONG).show();
        enablePermissions(PERMISSION_ID, true, Manifest.permission.ACCESS_FINE_LOCATION);
    }

    @Override
    protected void onGooglePlayServicesConnectionSuspended(int errorCode) {
        Toast.makeText(this, "Suspenso: " + errorCode, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onGooglePlayServicesConnectionFailure(int errorCode) {
        Toast.makeText(this, "Falhou: " + errorCode, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPermissionsNeeded(int requestPermissionId, List<String> permissions) {

    }

    @Override
    protected void onPermissionsDenied(int requestPermissionId, List<String> permissions) {

    }

    @Override
    protected void onPermissionsGranted(int requestPermissionId, List<String> permissions) throws SecurityException {
        FusedLocationProviderClient providerClient = LocationServices.getFusedLocationProviderClient(this);

        LocationCallback callback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult != null) {
                    for (Location location : locationResult.getLocations()) {
                        txtLatitude.setText(String.valueOf(location.getLatitude()));
                        txtLongitude.setText(String.valueOf(location.getLongitude()));
                    }
                }
            }
        };

        providerClient.requestLocationUpdates(request, callback, null);

        mockManager.startThread(3.456, 2.333, 0.02);

        providerClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {
                            Toast.makeText(MainActivity.this, "Localização: " + location.getLatitude() + ", " + location.getLongitude(), Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Localização não encontrada", Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
}
