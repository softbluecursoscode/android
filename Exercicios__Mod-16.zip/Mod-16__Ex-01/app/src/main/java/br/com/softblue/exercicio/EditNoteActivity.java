package br.com.softblue.exercicio;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class EditNoteActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {
	
	private EditText edtNote;
	private Note note;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_editnote);
		
		edtNote = findViewById(R.id.edt_note);
		
		long noteId = getIntent().getLongExtra("noteId", 0);
		
		if (noteId > 0) {
			// Se um ID foi fornecido, significa que é uma edição. Carrega os dados da nota na tela usando um loader
			Bundle bundle = new Bundle();
			bundle.putLong("noteId", noteId);
			getSupportLoaderManager().initLoader(0, bundle, this);
		}
	}
	
	public void cancelar(View view) {
		// Cancela a operação
		setResult(RESULT_CANCELED);
		finish();
	}
	
	public void gravar(View view) {
		final String conteudo = edtNote.getText().toString();
		
		if (note == null) {
			// Se a nota não existe, abre o dialog solicitando o nome dela
			NoteNameDialog.show(getSupportFragmentManager(), new NoteNameDialog.OnNoteNameSetListener() {
				@Override
				public void onNoteNameSet(String noteName) {
					// Obtém o nome escolhido pelo usuário e grava o registro no banco de dados
					saveContentToDBAndFinish(noteName, conteudo);
				}
			});
		
		} else {
			// Se a nota já existe, sobrescreve o conteúdo
			saveContentToDBAndFinish(null, conteudo);
		}
	}
	
	// Grava a nota no banco de dados e finaliza a activity
	private void saveContentToDBAndFinish(String nome, String conteudo) {
		if (note == null) {
			note = new Note();
			note.setNome(nome);
			note.setConteudo(conteudo);
			NoteDAO.insert(note);
		
		} else {
			note.setConteudo(conteudo);
			NoteDAO.update(note);
		}
		
		setResult(RESULT_OK);
		finish();
		Toast.makeText(this, "Nota gravada", Toast.LENGTH_SHORT).show();
	}

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		// Quando o loader é criado, carrega a nota
		long noteId = args.getLong("noteId");
		return NoteDAO.load(noteId);
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
		// Quando o carregamento dos dados é feito, extrai as informações do cursor e mostra na tela
		cursor.moveToFirst();
		note = new Note();
		note.loadFromCursor(cursor);
		edtNote.setText(note.getConteudo());
	}

	@Override
	public void onLoaderReset(Loader<Cursor> loader) {
	}
}
