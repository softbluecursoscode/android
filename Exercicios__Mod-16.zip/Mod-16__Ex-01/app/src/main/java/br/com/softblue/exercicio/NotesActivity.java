package br.com.softblue.exercicio;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class NotesActivity extends AppCompatActivity implements AdapterView.OnItemClickListener, OnItemLongClickListener, LoaderManager.LoaderCallbacks<Cursor> {

    private SimpleCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_notes);

        adapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1, null, new String[] { Note.COLUMN_NOME }, new int[] { android.R.id.text1 }, 0);

        ListView listView = findViewById(R.id.list);

        listView.setAdapter(adapter);

        // Registra evento de clique longo e curto nos itens da lista
        listView.setOnItemLongClickListener(this);
        listView.setOnItemClickListener(this);

        // Inicializa br.com.softblue.exercicio.NoteDAO
        NoteDAO.init(this);

        // Inicia o carregamento dos elementos com o uso de um loader
        getSupportLoaderManager().initLoader(0, null, this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actions, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_add) {
            // Cria uma nova nota
            Intent intent = new Intent(this, EditNoteActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        // Inicia a activity de edição
        Intent intent = new Intent(this, EditNoteActivity.class);
        intent.putExtra("noteId", id);
        startActivity(intent);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
        // Exclui a nota
        NoteDAO.delete(id);
        return true;
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        // Quando o loader é criado, obtém a lista de notas
        return NoteDAO.list();
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        // Quando os dados são carregados, são associados ao adapter
        adapter.swapCursor(cursor);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        adapter.swapCursor(null);
    }
}
