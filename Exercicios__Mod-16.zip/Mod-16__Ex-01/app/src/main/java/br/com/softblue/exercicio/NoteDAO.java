package br.com.softblue.exercicio;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.net.Uri;
import android.support.v4.content.CursorLoader;

public class NoteDAO {

	private static Context context;
	private static ContentResolver cr;

	// Inicializa a classe. Este método deve ser chamado apenas uma vez, antes de chamar os outros métodos
	public static void init(Context context) {
		NoteDAO.context = context.getApplicationContext();
		NoteDAO.cr = context.getContentResolver();
	}

	// Lista as notas cadastradas
	public static CursorLoader list() {
		return new CursorLoader(context, NotesProvider.CONTENT_URI, null, null, null, null);
	}
	
	// Carrega uma nota com um determinado ID
	public static CursorLoader load(long noteId) {
		Uri uri = ContentUris.withAppendedId(NotesProvider.CONTENT_URI, noteId);
		return new CursorLoader(context, uri, null, null, null, null);
	}

	// Insere uma nova nota
	public static void insert(Note note) {
		Uri uri = cr.insert(NotesProvider.CONTENT_URI, note.values());
		long id = ContentUris.parseId(uri);
		note.setId(id);
	}

	// Atualiza uma nota existente
	public static void update(Note note) {
		Uri uri = ContentUris.withAppendedId(NotesProvider.CONTENT_URI, note.getId());
		cr.update(uri, note.values(), null, null);
	}

	// Exclui uma nota
	public static void delete(long id) {
		Uri uri = ContentUris.withAppendedId(NotesProvider.CONTENT_URI, id);
		cr.delete(uri, null, null);
	}
}
