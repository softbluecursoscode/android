package br.com.softblue.exercicio;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

// Content provider que dá acesso ao banco de dados SQLite
public class NotesProvider extends ContentProvider {

	private static final String AUTHORITY = "br.com.softblue.exercicio.NotesProvider";
	public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/notes");

	private static final int MATCH_ONE = 1;
	private static final int MATCH_ALL = 2;

	private SQLiteDatabase db;
	private UriMatcher matcher;

	@Override
	public boolean onCreate() {
		// Obtém a instância do SQLiteDatabase
		db = DBHandler.getInstance(getContext()).getWritableDatabase();

		// Configura o matcher
		matcher = new UriMatcher(UriMatcher.NO_MATCH);
		matcher.addURI(AUTHORITY, "/notes", MATCH_ALL);
		matcher.addURI(AUTHORITY, "/notes/#", MATCH_ONE);

		return true;
	}

	@Override
	public String getType(Uri uri) {
		int type = matcher.match(uri);

		if (type == MATCH_ONE) {
			return "vnd.android.cursor.item/vnd.softblue.android";

		} else if (type == MATCH_ALL) {
			return "vnd.android.cursor.dir/vnd.softblue.android";
		}

		throw new IllegalArgumentException("A URI não é suportada");
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		long id = db.insert(Note.TABLE_NAME, null, values);
		Uri newUri = ContentUris.withAppendedId(uri, id);
		getContentResolver().notifyChange(newUri, null);
		return newUri;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
		long id = ContentUris.parseId(uri);
		int count = db.update(Note.TABLE_NAME, values, Note.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
		getContentResolver().notifyChange(uri, null);
		return count;
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		long id = ContentUris.parseId(uri);
		int count = db.delete(Note.TABLE_NAME, Note.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
		getContentResolver().notifyChange(uri, null);
		return count;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
		String[] columns = {Note.COLUMN_ID, Note.COLUMN_NOME, Note.COLUMN_CONTEUDO};

		Cursor c;
		if (matcher.match(uri) == MATCH_ALL) {
			// Se a busca for por todos os registros, seleciona sem restrições
			c = db.query(Note.TABLE_NAME, columns, null, null, null, null, null);

		} else {
			// Se a busca for por um registro específico, seleciona com base no ID
			long id = ContentUris.parseId(uri);
			c = db.query(Note.TABLE_NAME, columns, Note.COLUMN_ID + " = ?", new String[]{String.valueOf(id)}, null, null, null);
		}

		c.setNotificationUri(getContentResolver(), uri);
		return c;
	}

	public ContentResolver getContentResolver() {
        if (getContext() != null) {
            return getContext().getContentResolver();
        }
        return null;
	}
}
