package br.com.softblue.exercicio;

import java.io.Serializable;

import android.content.ContentValues;
import android.database.Cursor;

@SuppressWarnings("serial")
public class Note implements Serializable {

	public static final String TABLE_NAME = "note";
	public static final String COLUMN_ID = "_id";
	public static final String COLUMN_NOME = "nome";
	public static final String COLUMN_CONTEUDO = "conteudo";
	
	private long id;
	private String nome;
	private String conteudo;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getConteudo() {
		return conteudo;
	}

	public void setConteudo(String conteudo) {
		this.conteudo = conteudo;
	}

	public void loadFromCursor(Cursor c) {
		this.id = c.getLong(c.getColumnIndex(COLUMN_ID));
		this.nome = c.getString(c.getColumnIndex(COLUMN_NOME));
		this.conteudo = c.getString(c.getColumnIndex(COLUMN_CONTEUDO));
	}
	
	public ContentValues values() {
		ContentValues values = new ContentValues();
		values.put(COLUMN_NOME, nome);
		values.put(COLUMN_CONTEUDO, conteudo);
		return values;
	}
	
	@Override
	public String toString() {
		return nome;
	}
}
