package br.com.softblue.exercicio;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    private static final int PERMISSION_READ_CONTACTS_REQUEST_CODE = 123;

	private SimpleCursorAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);
		
		// Cria os arrays para o mapeamento dos dados do cursor no adapter
		String[] from = { ContactsContract.Contacts.DISPLAY_NAME_PRIMARY };
		int[] to = { android.R.id.text1 };

		// Cria o adapter
		adapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1, null, from, to, 0);

		ListView listView = findViewById(R.id.list);
		listView.setAdapter(adapter);

        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{ Manifest.permission.READ_CONTACTS }, PERMISSION_READ_CONTACTS_REQUEST_CODE);

        } else {
            // Inicia o carregamento com o uso de um loader
            getSupportLoaderManager().initLoader(0, null, this);
        }
	}

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		String[] columns = {
				ContactsContract.Contacts._ID,
				ContactsContract.Contacts.DISPLAY_NAME_PRIMARY
		};
		
		// Faz a busca no content provider de dicionário
		return new CursorLoader(this, ContactsContract.Contacts.CONTENT_URI, columns, null, null, null);
	}

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSION_READ_CONTACTS_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Inicia o carregamento com o uso de um loader
                getSupportLoaderManager().initLoader(0, null, this);
            } else {
                Toast.makeText(this, "A permissão não foi concedida", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
		adapter.swapCursor(cursor);
	}

	@Override
	public void onLoaderReset(Loader<Cursor> loader) {
		adapter.swapCursor(null);
	}
}
