package br.com.softblue.exercicio;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.Manifest;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import br.com.softblue.exercicio.permission.PermissionActivity;
import br.com.softblue.exercicio.permission.PermissionDialog;

public class MyMapActivity extends PermissionActivity implements OnMapLongClickListener, OnMapReadyCallback, PermissionDialog.OnPermissionDialogListener {
	
	// Objeto para interação com o mapa
	private GoogleMap map;
	
	// Botão do cálculo da distância
	private Button btnCalculate;
	
	// Lista de marcadores adicionados no mapa
	private List<Marker> markers = new ArrayList<>();
	
	// Polyline que liga os pontos marcados no mapa
	private Polyline polyline;

	// Indica se a distância foi calculada
	private boolean hasDistance;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Define o layout
		setContentView(R.layout.activity_my_map);
		
		// Obtêm a referência ao botão e o desabilita (o botão só pode ser usado se
		// dois ou mais marcadores existirem no mapa)
		btnCalculate = findViewById(R.id.btn_calculate);
		btnCalculate.setEnabled(false);

		// Obtém a referência ao mapa
		((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map)).getMapAsync(this);
	}

	@Override
	public void onMapLongClick(LatLng pos) {
		// Só processa o clique longo se a distância ainda não foi calculada
		if (hasDistance) {
			return;
		}

		// Ao dar um clique longo no mapa, um novo marcador é adicionado na posição do clique
		MarkerOptions options = new MarkerOptions().position(pos);
		markers.add(map.addMarker(options));
		
		// Se já existem 2 ou mais marcadores, habilita o botão de cálculo
		if (markers.size() >= 2) {
			btnCalculate.setEnabled(true);
		}
	}
	
	// Cria o polyline e calcula a distância total
	public void calculate(View view) {
		// Define que o polyline terá cor vermelha
		PolylineOptions options = new PolylineOptions();
		options.color(Color.RED);
		
		// Adiciona pontos no polyline com base nas posições dos marcadores.
		// Também remove os marcadores
		for (Marker marker : markers) {
			options.add(marker.getPosition());
			marker.remove();
		}
		
		// Adiciona o polyline no mapa
		polyline = map.addPolyline(options);
		
		// Efetua o cálculo da distância total, com base nos pontos do polyline
		List<LatLng> points = polyline.getPoints();
		double totalDistance = 0;
		for (int i = 1; i < points.size(); i++) {
			// O cálculo começa a partir do ponto 2. Primeiro é calculada a distância de 2 até o 1,
			// depois de 3 até o 2, depois de 4 até o 3 e assim por diante. As distâncias parciais
			// são somadas, a fim de calcular o valor total
			
			double distance = calculateDistance(points.get(i), points.get(i - 1));
			Log.i("App", String.format("P%d => P%d = %f Km", i - 1, i, distance));
			totalDistance += distance;
		}
		
		// Mostra na tela a distância total calculada
		Toast.makeText(this, String.format(new Locale("pt", "BR"), "A distância total é de %.2f Km", totalDistance), Toast.LENGTH_LONG).show();

		// Desabilita o botão de cálculo
		btnCalculate.setEnabled(false);

		// A distância foi calculada
		hasDistance = true;
	}
	
	// Limpa os marcadores e polyline
	public void clear(View view) {
		// Remove todos os marcadores
		for (Marker marker : markers) {
			marker.remove();
		}
		
		// Tira os marcadores da lista
		markers.clear();
		
		// Se o polyline existe, remove
		if (polyline != null) {
			polyline.remove();
			polyline = null;
		}
		
		// Desabilita o botão de cálculo
		btnCalculate.setEnabled(false);

		// A distância não foi mais calculada
		hasDistance = false;
	}
	
	// Este método calcula a distância em Km entre dois pontos
	private double calculateDistance(LatLng p1, LatLng p2) {	
		float[] results = new float[1];
		Location.distanceBetween(p1.latitude, p1.longitude, p2.latitude, p2.longitude, results);
		return results[0] / 1000;
	}

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.map = googleMap;

        // Adiciona o listener para eventos de clique longo no mapa
        map.setOnMapLongClickListener(this);

        map.getUiSettings().setMyLocationButtonEnabled(true);

        // Habilita os controles de zoom e a bússola
        map.getUiSettings().setZoomControlsEnabled(true);
        map.getUiSettings().setCompassEnabled(true);

		enablePermissions(0, true, Manifest.permission.ACCESS_FINE_LOCATION);
    }

	@Override
	protected void onPermissionsNeeded(int requestPermissionId, List<String> permissions) {
		showPermissionDialog(0, "Esta permissão é obrigatória. Deseja concedê-la?");
	}

	@Override
	protected void onPermissionsDenied(int requestPermissionId, List<String> permissions) {
		Toast.makeText(this, "Sem a permissão não é possível continuar", Toast.LENGTH_SHORT).show();
	}

	@Override
	protected void onPermissionsGranted(int requestPermissionId, List<String> permissions) throws SecurityException {
		// Habilita a minha localização
		map.setMyLocationEnabled(true);
	}

	@Override
	public void onPermissionDialogResult(int dialogId, boolean accepted) {
		if (accepted) {
			enablePermissions(0, false, Manifest.permission.ACCESS_FINE_LOCATION);

		} else {
			Toast.makeText(this, "Sem a permissão não é possível continuar", Toast.LENGTH_SHORT).show();
		}
	}
}
