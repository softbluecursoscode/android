package br.com.softblue.exercicio;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.CancelableCallback;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;

public class MyMapActivity extends FragmentActivity implements OnMapClickListener, CancelableCallback, OnMapReadyCallback {
	
	// Objeto para interação com o mapa
	private GoogleMap map;
	
	// Array com as posições por onde a câmera deve passar
	private LatLng[] positions = new LatLng[] {
		new LatLng(-50.0, -50.0),
		new LatLng(-50.0,  50.0),
		new LatLng( 50.0,  50.0),
		new LatLng( 50.0, -50.0)
	};
	
	// Armazena a posição atual (para onde a câmera está indo)
	private int currentPos;
	
	// Controla se a animação já começou
	private boolean started;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Define o layout
		setContentView(R.layout.activity_my_map);
		
		// Obtém a referência ao mapa
		((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map)).getMapAsync(this);
	}

	@Override
	public void onMapClick(LatLng pos) {
		// Chamado quando ocorrer um click no mapa.
		// A variável started controla se um clique já foi dado, para desconsiderar outros cliques
		if (!started) {
			started = true;
			
			// Vai para a próxima posição
			goToNextLocation();
		}
	}

	@Override
	public void onCancel() {
	}

	@Override
	public void onFinish() {
		// Quando a animação terminar, vai para próxima
		goToNextLocation();
	}

	private void goToNextLocation() {
		// Descobre a próxima posição. Se o array de posições chegar ao final, volta para a posição 0
		// (isto faz com que a animação não termine mais)
		currentPos = (currentPos + 1) % positions.length;
		
		// Anima a câmera até a nova posição
		CameraUpdate update = CameraUpdateFactory.newLatLng(positions[currentPos]);
		map.animateCamera(update, 5000, this);
		
		// Mostra na tela para onde a câmera está indo
		double lat = positions[currentPos].latitude;
		double lng = positions[currentPos].longitude;
		Toast.makeText(this, "Indo para " + lat + ", " + lng, Toast.LENGTH_SHORT).show();
	}

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.map = googleMap;

        // Adiciona o listener para eventos de clique no mapa
        map.setOnMapClickListener(this);

        // Desabilita os gestos, evitando que o usuário interfira na animação
        map.getUiSettings().setAllGesturesEnabled(false);

        // Posiciona a câmera na primeira posição do mapa definida, com zoom 3
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(positions[currentPos], 3);
        map.moveCamera(update);
    }
}
