package br.com.softblue.exercicio;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;

public class MyMapActivity extends FragmentActivity implements OnCheckedChangeListener, OnMapReadyCallback {
	
	// Objeto para interação com o mapa
	private GoogleMap map;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Define o layout
		setContentView(R.layout.activity_my_map);
		
		// Obtém a referência ao checkbox e adiciona um listener para ser invocado
		// quando ele for marcado ou desmarcado
		CheckBox satellite = findViewById(R.id.chk_sat);
		satellite.setOnCheckedChangeListener(this);
		
		// Obtém a referência ao mapa
		((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map)).getMapAsync(this);
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// Este método é chamado quando o checkbox é clicado
		// Ele define o estado do mapa através da chamada a setMapType()
		if (isChecked) {
			map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
		} else {
			map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
		}
	}

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.map = googleMap;

        // Habilita os controles de zoom
        map.getUiSettings().setZoomControlsEnabled(true);

        // Posiciona a câmera em um local do mapa com zoom 3
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(new LatLng(-15.783333, -47.916667), 3);
        map.moveCamera(update);
    }
}
