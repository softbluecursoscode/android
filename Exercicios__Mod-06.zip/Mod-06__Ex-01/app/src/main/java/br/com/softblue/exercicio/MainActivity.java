package br.com.softblue.exercicio;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity implements ButtonFragment.ChangeColorListener {

	private ColorFragment colorFragment;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_main);
		
		// Armazena a referência ao fragment de cor
		colorFragment = (ColorFragment) getFragmentManager().findFragmentById(R.id.fra_color);
	}

	@Override
	public void changeColor(int color) {
		// Muda a cor do fragment
		colorFragment.setColor(color);
	}
}
