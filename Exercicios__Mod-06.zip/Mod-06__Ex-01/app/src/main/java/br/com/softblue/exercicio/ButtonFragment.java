package br.com.softblue.exercicio;

import android.app.Fragment;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ButtonFragment extends Fragment implements View.OnClickListener {
	
	private ChangeColorListener listener;
	
	@Override
	public void onAttach(Context context) {
		super.onAttach(context);
		
		// Verifica se a activity implementa ChangeColorListener
		if (!(context instanceof ChangeColorListener)) {
			throw new IllegalArgumentException("A activity deve implementar a interface ChangeColorListener");
		}
		
		// Salva o listener para ser chamado mais tarde
		this.listener = (ChangeColorListener) context;
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_button, container, false);
		
		// Adiciona os listeners de clique aos botões
		view.findViewById(R.id.btn_black).setOnClickListener(this);
		view.findViewById(R.id.btn_blue).setOnClickListener(this);
		view.findViewById(R.id.btn_green).setOnClickListener(this);
		view.findViewById(R.id.btn_red).setOnClickListener(this);
		view.findViewById(R.id.btn_yellow).setOnClickListener(this);
		
		return view;
	}

	/**
	 * Método chamado quando algum botão é clicado
	 */
	@Override
	public void onClick(View v) {
		// Identifica a cor de acordo com o botão clicado

		int color;
		int id = v.getId();
		
		if (id == R.id.btn_black) {
			color = Color.BLACK;
		} else if (id == R.id.btn_blue) {
			color = Color.BLUE;
		} else if (id == R.id.btn_green) {
			color = Color.GREEN;
		} else if (id == R.id.btn_red) {
			color = Color.RED;
		} else if (id == R.id.btn_yellow) {
			color = Color.YELLOW;
		} else {
			color = Color.WHITE;
		}
		
		// Avisa a activity que a cor deve ser mudada
		listener.changeColor(color);
	}
	
	/**
	 * Interface para avisar sobre o a mudança de cor
	 */
	public interface ChangeColorListener {
		void changeColor(int color);
	}
}
