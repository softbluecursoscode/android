package br.com.softblue.exercicio;

public class Count1Fragment extends CountFragment {
	private static final long serialVersionUID = 1L;
	
	public static final String TAG = "Count1Fragment";

	@Override
	protected int getFragmentView() {
		return R.layout.fragment_count1;
	}
}
