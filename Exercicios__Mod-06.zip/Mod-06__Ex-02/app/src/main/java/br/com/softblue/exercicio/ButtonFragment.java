package br.com.softblue.exercicio;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class ButtonFragment extends Fragment implements View.OnClickListener {
	public static final String TAG = "ButtonFragment";
	
	private IncrementListener listener;
	
	@Override
	public void onAttach(Context context) {
		super.onAttach(context);
		
		// Verifica se a activity implementa IncrementListener
		if (!(context instanceof IncrementListener)) {
			throw new IllegalArgumentException("A activity deve implementar a interface IncrementListener");
		}
		
		// Salva o listener para ser chamado mais tarde
		this.listener = (IncrementListener) context;
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_button, container, false);
		
		// Adiciona o listener de clique ao botão
		Button button = view.findViewById(R.id.btn_increment);
		button.setOnClickListener(this);
		
		return view;
	}

	/**
	 * Método chamado quando o botão é clicado
	 */
	@Override
	public void onClick(View v) {
		// Avisa a activity para que ela coordene os incrementos
		listener.increment();
	}
	
	/**
	 * Interface para avisar sobre o momento de incrementar os contadores
	 */
	public interface IncrementListener {
		void increment();
	}
}
