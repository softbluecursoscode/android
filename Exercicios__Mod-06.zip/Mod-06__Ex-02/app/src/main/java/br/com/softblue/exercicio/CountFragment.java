package br.com.softblue.exercicio;

import java.io.Serializable;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Esta classe implementa o que é comum entre os fragments que exibem o contador.
 */
public abstract class CountFragment extends Fragment implements Serializable {
	private static final long serialVersionUID = 1L;

	private TextView txtCount;
	
	// Valor atual da contagem
	private int count;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(getFragmentView(), container, false);
		
		txtCount = view.findViewById(R.id.txt_count);
		
		if (savedInstanceState != null) {
			// O fragment está sendo recriado, então lê os dados do bundle
			this.count = savedInstanceState.getInt("count");
		}
		
		// Inicia o texto com 0
		txtCount.setText(String.valueOf(count));
		
		return view;
	}
	
	public void increment() {
		// Incrementa o valor do contador
		count++;
		
		// Exibe o novo valor
		txtCount.setText(String.valueOf(count));
	}
	
	/**
	 * Este método é implementado pelas subclasses para retornar seu ID de layout.
	 */
	protected abstract int getFragmentView();
	
	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		
		// Armazena o valor do contador quando o fragment está prestes a ser destruído
		outState.putInt("count", count);
	}
}
