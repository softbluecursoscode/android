package br.com.softblue.exercicio;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;

public class MainActivity extends Activity implements ButtonFragment.IncrementListener {

	private CountFragment count1Fragment;
	private CountFragment count2Fragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_main);
		
		// Obtém o FragmentManager
		FragmentManager fm = getFragmentManager();
		
		// Inicia uma fragment transaction
		FragmentTransaction ft = fm.beginTransaction();
		
		// Os códigos abaixo verificam primeiro se o fragment já não existe (através de findFragmentByTag()).
		// Quando ocorre a recriação da activity, o Android adiciona novamente os fragments de forma automática.
		// Por isso testar se o fragment já não existe na activity é importante.

		// Adiciona o contador 1
		count1Fragment = (CountFragment) fm.findFragmentByTag(Count1Fragment.TAG);
		if (count1Fragment == null) {
			count1Fragment = new Count1Fragment();
			ft.add(R.id.lay_count1, count1Fragment, Count1Fragment.TAG);
		}
		
		// Adiciona o contador 2
		count2Fragment = (CountFragment) fm.findFragmentByTag(Count2Fragment.TAG);
		if (count2Fragment == null) {
			count2Fragment = new Count1Fragment();
			ft.add(R.id.lay_count2, count2Fragment, Count2Fragment.TAG);
		}
		
		// Adiciona o botão
		ButtonFragment buttonFragment = (ButtonFragment) fm.findFragmentByTag(ButtonFragment.TAG);
		if (buttonFragment == null) {
			buttonFragment = new ButtonFragment();
			ft.add(R.id.lay_button, buttonFragment, ButtonFragment.TAG);
		}
		
		// Finaliza a fragment transaction
		ft.commit();
	}

	/**
	 * Este método será chamado pelo ButtonFragment quando o usuário pressionar o botão
	 */
	@Override
	public void increment() {
		// Pede para que os fragments incrementem seus valores
		count1Fragment.increment();
		count2Fragment.increment();
	}
}
