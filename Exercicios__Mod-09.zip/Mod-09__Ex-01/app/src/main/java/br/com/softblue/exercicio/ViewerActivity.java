package br.com.softblue.exercicio;

import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;

public class ViewerActivity extends Activity {
	
	public static final String EXTRA_IMAGE_PATH = "imagePath";
	public static final String EXTRA_ERROR = "error";
	public static final int EXTRA_ERROR_NO_PATH = 100;
	public static final int EXTRA_ERROR_FILE_DOES_NOT_EXIST = 110;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_viewer);
		
		// Lê o caminho da imagem a ser mostrada
		String path = getIntent().getStringExtra(EXTRA_IMAGE_PATH);
		
		// Se nenhum caminho foi especificado, retorna erro
		if (path == null) {
			Intent intent = new Intent();
			intent.putExtra(EXTRA_ERROR, EXTRA_ERROR_NO_PATH);
			setResult(RESULT_CANCELED, intent);
			finish();
			return;
		}
		
		// Obtém o AssetManager
		AssetManager am = getAssets();
		
		try {
			
			// Abre o arquivo localizado na pasta assets
			InputStream in = am.open(path);
			
			// Gera um Drawable a partir da InputStream
			Drawable drawable = BitmapDrawable.createFromStream(in, path);
			
			// Obtém a referência ao ImageView da tela
			ImageView view = findViewById(R.id.image);
			
			// Define a imagem a ser mostrada
			view.setImageDrawable(drawable);
		
		} catch (IOException e) {
			// Se ocorrer exceção, retorna erro
			Intent intent = new Intent();
			intent.putExtra(EXTRA_ERROR, EXTRA_ERROR_FILE_DOES_NOT_EXIST);
			setResult(RESULT_CANCELED, intent);
			finish();
		}
	}
	
	@Override
	public void onBackPressed() {
		// Método chamado quando o botão Voltar (Back) é pressionado.
		// Define o resultado como OK e encerra a activity
		setResult(RESULT_OK);
		finish();
	}
}
