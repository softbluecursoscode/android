package br.com.softblue.exercicio;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {

	// Constante para controlar o retorno da activity de visualização
	private static final int VIEW_REQUEST = 10;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);
	}

	public void show(View view) {
		// Cria a intent com os dados
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setType("image/png");
		intent.putExtra(ViewerActivity.EXTRA_IMAGE_PATH, "images/image.png");
		
		// Abre a activity de visualização
		startActivityForResult(intent, VIEW_REQUEST);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// Se ocorreu algum erro, mostra o erro
		
		if (requestCode == VIEW_REQUEST && resultCode == RESULT_CANCELED) {
			int error = data.getIntExtra(ViewerActivity.EXTRA_ERROR, 0);

			Toast.makeText(this, "Erro: " + error, Toast.LENGTH_LONG).show();
		}
	}
}
