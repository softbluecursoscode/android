package br.com.softblue.exercicio;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Telephony;
import android.telephony.SmsMessage;

public class AutoCallReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		// Extrai os dados do SMS
		SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
		SmsMessage sms = messages[0];

		String remetente = sms.getOriginatingAddress();
		String texto = sms.getMessageBody();

		// Lê o texto a ser comparado do arquivos de recursos
		String textoSMS = context.getString(R.string.texto_sms);

		if (textoSMS.equalsIgnoreCase(texto)) {
			// Só faz a ligação se o texto for 'ligar'
			Uri uri = Uri.parse("tel:" + remetente);
			
			// Cria a intent para fazer a ligação
			Intent i = new Intent(Intent.ACTION_CALL, uri);
			
			// Define a flag ACTIVITY_NEW_TASK na intent. É necessário para chamar uma activity a partir de um broadcast receiver
			i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

			// Faz a ligação
			try {
				context.startActivity(i);

			} catch (SecurityException e) {
				// Não vai chegar aqui porque as permissões são concedidas na activity
				e.printStackTrace();
			}
		}
	}
}
