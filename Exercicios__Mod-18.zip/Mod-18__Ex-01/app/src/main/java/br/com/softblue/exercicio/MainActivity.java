package br.com.softblue.exercicio;

import android.Manifest;
import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

import br.com.softblue.exercicio.permission.PermissionActivity;
import br.com.softblue.exercicio.permission.PermissionDialog;

public class MainActivity extends PermissionActivity implements PermissionDialog.OnPermissionDialogListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void onStart() {
		super.onStart();
		enablePermissions(0, true, Manifest.permission.CALL_PHONE, Manifest.permission.RECEIVE_SMS);
	}

	@Override
	protected void onPermissionsNeeded(int requestPermissionId, List<String> permissions) {
		showPermissionDialog(0, "Sem as permissões o aplicativo não funciona. Aceita as permissões?");
	}

	@Override
	protected void onPermissionsDenied(int requestPermissionId, List<String> permissions) {
		Toast.makeText(this, "Sem as permissões não é possível continuar", Toast.LENGTH_SHORT).show();
	}

	@Override
	protected void onPermissionsGranted(int requestPermissionId, List<String> permissions) throws SecurityException {
		Toast.makeText(this, "Tudo OK com as permissões!", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onPermissionDialogResult(int dialogId, boolean accepted) {
		if (accepted) {
			enablePermissions(0, false, Manifest.permission.CALL_PHONE, Manifest.permission.RECEIVE_SMS);
		} else {
			Toast.makeText(this, "Sem as permissões não é possível continuar", Toast.LENGTH_SHORT).show();
		}
	}
}
