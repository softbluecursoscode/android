package br.com.softblue.exercicio;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Classe para acesso ao banco de dados SQLite
public class DBHandler extends SQLiteOpenHelper {

	// Nome do banco de dados
	private static final String DB_NAME = "notesdb";
	
	// Versão do banco de dados
	private static final int DB_VERSION = 1;
	
	// Script para criação da tabela
	private static final String SCRIPT_CREATE = "CREATE TABLE note (_id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, conteudo TEXT)";

	private static DBHandler instance;

	// Obtém a instância do DBHandler. Esta classe implementa o padrão singleton, onde sempre a mesma instância é retornada.
	// O construtor é privado, portanto não pode ser chamado de fora da classe. O método getInstance() cria o objeto na primeira chamada.
	// Nas chamadas subsequentes, retorna o mesmo objeto
	public static DBHandler getInstance(Context context) {
		if (instance == null) {
			instance = new DBHandler(context.getApplicationContext());
		}
		return instance;
	}

	private DBHandler(Context context) {
		super(context, DB_NAME, null, DB_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(SCRIPT_CREATE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// Não faz nada
	}
}
