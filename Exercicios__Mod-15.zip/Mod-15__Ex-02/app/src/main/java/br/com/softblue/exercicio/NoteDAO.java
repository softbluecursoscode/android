package br.com.softblue.exercicio;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

// Classe de acesso ao banco de dados
public class NoteDAO {

	// Referência ao banco de dados
	private static SQLiteDatabase db;

	// Inicializa a classe. Este método deve ser chamado apenas uma vez, antes de chamar os outros métodos
	public static void init(Context context) {
		db = DBHandler.getInstance(context).getWritableDatabase();
	}

	// Lista as notas cadastradas
	public static List<Note> list() {
		String[] columns = { Note.COLUMN_ID, Note.COLUMN_NOME, Note.COLUMN_CONTEUDO };

		List<Note> notes = new ArrayList<>();

		try (Cursor c = db.query(Note.TABLE_NAME, columns, null, null, null, null, Note.COLUMN_NOME)) {
			if (c.moveToFirst()) {
				do {
					Note note = new Note();
					note.loadFromCursor(c);
					notes.add(note);
				} while (c.moveToNext());
			}

			return notes;
		}
	}

	// Insere uma nova nota
	public static void insert(Note note) {
		long id = db.insert(Note.TABLE_NAME, null, note.values());
		note.setId(id);
	}

	// Atualiza uma nota existente
	public static void update(Note note) {
		db.update(Note.TABLE_NAME, note.values(), Note.COLUMN_ID + " = ?", new String[] { String.valueOf(note.getId()) });
	}

	// Exclui uma nota
	public static void delete(Note note) {
		db.delete(Note.TABLE_NAME, Note.COLUMN_ID + " = ?", new String[] { String.valueOf(note.getId()) });
	}
}
