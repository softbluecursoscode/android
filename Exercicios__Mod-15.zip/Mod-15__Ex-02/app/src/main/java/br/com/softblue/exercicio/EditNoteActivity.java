package br.com.softblue.exercicio;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class EditNoteActivity extends AppCompatActivity {
	
	private EditText edtNote;
	private Note note;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_edit_note);
		
		edtNote = findViewById(R.id.edt_note);
		
		note = (Note) getIntent().getSerializableExtra("note");
		
		if (note != null) {
			// Se note existe, significa que é uma edição. Carrega os dados da nota na tela
			edtNote.setText(note.getConteudo());
		}
	}
	
	public void cancelar(View view) {
		// Cancela a operação
		setResult(RESULT_CANCELED);
		finish();
	}
	
	public void gravar(View view) {
		final String conteudo = edtNote.getText().toString();
		
		if (note == null) {
			// Se a nota não existe, abre o dialog solicitando o nome dela
			NoteNameDialog.show(getSupportFragmentManager(), new NoteNameDialog.OnNoteNameSetListener() {
				@Override
				public void onNoteNameSet(String noteName) {
					// Obtém o nome escolhido pelo usuário e grava o registro no banco de dados
					saveContentToDBAndFinish(noteName, conteudo);
				}
			});
		
		} else {
			// Se a nota já existe, sobrescreve o conteúdo
			saveContentToDBAndFinish(null, conteudo);
		}
	}
	
	// Grava a nota no banco de dados e finaliza a activity
	private void saveContentToDBAndFinish(String nome, String conteudo) {
		if (note == null) {
			note = new Note();
			note.setNome(nome);
			note.setConteudo(conteudo);
			NoteDAO.insert(note);
		
		} else {
			note.setConteudo(conteudo);
			NoteDAO.update(note);
		}
		
		setResult(RESULT_OK);
		finish();
		Toast.makeText(this, "Nota gravada", Toast.LENGTH_SHORT).show();
	}
}
