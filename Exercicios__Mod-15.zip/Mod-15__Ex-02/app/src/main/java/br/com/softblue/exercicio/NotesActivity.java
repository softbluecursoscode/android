package br.com.softblue.exercicio;

import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class NotesActivity extends AppCompatActivity implements OnItemLongClickListener, AdapterView.OnItemClickListener {

	private ArrayAdapter<Note> adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_notes);
		ListView listView = findViewById(R.id.list);
		
		// Habilita a up navigation
		if (getSupportActionBar() != null) {
			getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		}

		adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
		listView.setAdapter(adapter);
		
		// Registra evento de clique longo nos itens da lista
		listView.setOnItemLongClickListener(this);
		listView.setOnItemClickListener(this);
		
		NoteDAO.init(this);

		// Atualiza a lista
		refreshList();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.actions, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == R.id.action_add) {
			// Cria uma nova nota
			Intent intent = new Intent(this, EditNoteActivity.class);
			startActivityForResult(intent, 0);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK) {
			// Se o usuário efetivou a gravação, atualiza a lista para exibir a nova nota
			refreshList();
		}
	}

	private void refreshList() {
		// Limpa a lista
		adapter.clear();
		
		// Obtém as notas gravadas
		List<Note> notes = NoteDAO.list();

		// Adiciona os nomes das notas ao adapter
		adapter.addAll(notes);
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
		// Exclui a nota
		NoteDAO.delete(adapter.getItem(position));
		
		// Atualiza a lista
		refreshList();
		
		return true;
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// Obtém a nota clicada
		Note note = adapter.getItem(position);

		// Inicia a activity de edição
		Intent intent = new Intent(this, EditNoteActivity.class);
		intent.putExtra("note", note);
		startActivity(intent);
	}
}
