package br.com.softblue.exercicio;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.widget.EditText;

// Dialog para digitação do nome do arquivo
public class FileNameDialog extends DialogFragment {

	// Listener para avisar sobre a definição do nome do arquivo
	private OnFileNameSetListener listener;
	
	private EditText edtFileName;
	
	// Exibe o dialog
	public static void show(FragmentManager fm, OnFileNameSetListener listener) {
		FileNameDialog dialog = new FileNameDialog();
		dialog.listener = listener;
		dialog.show(fm, "fileNameDialog");
	}
	
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		
		builder.setTitle(R.string.dialog_title);
		builder.setPositiveButton(R.string.dialog_btn_ok, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				if (listener != null) {
					String fileName = edtFileName.getText().toString();
					listener.onFileNameSet(fileName);
				}
			}
		});
		
		// Define uma view customizada para o dialog
		View view = getActivity().getLayoutInflater().inflate(R.layout.dialog_filename, null);
		edtFileName = view.findViewById(R.id.edt_filename);
		
		builder.setView(view);
		
		return builder.create();
	}
	
	
	public interface OnFileNameSetListener {
		void onFileNameSet(String fileName);
	}
}
