package br.com.softblue.exercicio;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class ChooseStorageActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
	
	// Armazenamento interno
	public static final int STORAGE_TYPE_INTERNAL = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_choosestorage);
		ListView listView = findViewById(R.id.list);

		// Cria o adapter para a lista com base em um resouce de array
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.storage_types, android.R.layout.simple_list_item_1);
		listView.setAdapter(adapter);

		listView.setOnItemClickListener(this);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// Identifica se a opção escolhida foi área interna ou externa
		boolean internal = position == STORAGE_TYPE_INTERNAL;

		if (!internal && !Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
			// Se foi externa, checa se a área está pronta
			Toast.makeText(this, "A área de armazenamento não está pronta", Toast.LENGTH_SHORT).show();

		} else {
			// Se está tudo ok, abre a lista de arquivos da área
			Intent intent = new Intent(this, FilesActivity.class);
			intent.putExtra("storageType", internal);
			startActivity(intent);
		}
	}
}
