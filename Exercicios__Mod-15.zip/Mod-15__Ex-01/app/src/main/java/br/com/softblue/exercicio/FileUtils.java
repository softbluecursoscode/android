package br.com.softblue.exercicio;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

public class FileUtils {

	// Retorna o conteúdo de um arquivo como uma String
	public static String getFileAsString(File file) {
		if (file == null || !file.exists() || file.isDirectory()) {
			return null;
		}

		StringWriter out = new StringWriter();

		FileReader in = null;
		try {
			try {
				in = new FileReader(file);
				char[] buffer = new char[1024];

				while (true) {
					int read = in.read(buffer);

					if (read < 0) {
						break;
					}

					out.write(buffer, 0, read);
				}

				return out.toString();

			} finally {
				if (in != null) {
					in.close();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	// Grava um texto em um arquivo
	public static void writeStringToFile(String string, File file) {
		PrintWriter out = null;
		
		try {
			try {
				out = new PrintWriter(new FileWriter(file));
				out.print(string);
			} finally {
				if (out != null) {
					out.close();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
