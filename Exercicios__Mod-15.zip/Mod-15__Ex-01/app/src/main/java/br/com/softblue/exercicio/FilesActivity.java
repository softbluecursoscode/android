package br.com.softblue.exercicio;

import java.io.File;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class FilesActivity extends AppCompatActivity implements OnItemLongClickListener, OnItemClickListener {

	private ArrayAdapter<String> adapter;
	private File dir;
	private boolean internal;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_files);
		
		// Habilita a up navigation
		if (getSupportActionBar() != null) {
			getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		}
		internal = getIntent().getBooleanExtra("storageType", false);

		adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);

		ListView listView = findViewById(R.id.list);

		listView.setAdapter(adapter);
		
		// Registra evento de clique longo e curto nos itens da lista
		listView.setOnItemLongClickListener(this);
		listView.setOnItemClickListener(this);

		// Atualiza a lista
		refreshList();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.actions, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == R.id.action_add) {
			// Cria um novo arquivo
			Intent intent = new Intent(this, EditFileActivity.class);
			intent.putExtra("dir", dir);
			startActivityForResult(intent, 0);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK) {
			// Se o usuário efetivou a gravação, atualiza a lista para exibir o novo arquivo
			refreshList();
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// Obtém o arquivo clicado
		String fileName = adapter.getItem(position);
		File file = new File(dir, fileName);

		// Inicia a activity de edição
		Intent intent = new Intent(this, EditFileActivity.class);
		intent.putExtra("file", file);
		startActivity(intent);
	}

	// Obtém os arquivos de área interna ou externa
	private File[] getFiles(boolean internal) {
		if (internal) {
			// Lê da área interna
			dir = getFilesDir();
		} else {
			// Lê da área externa, diretório 'Notas'
			dir = getExternalFilesDir("Notas");
		}

		if (dir != null) {
			return dir.listFiles();
		}

		return null;
	}
	
	private void refreshList() {
		// Limpa a lista
		adapter.clear();
		
		// Obtém os arquivos gravados
		File[] files = getFiles(internal);

		// Adiciona os nomes dos arquivos ao adapter
        if (files != null) {
            for (File file : files) {
                adapter.add(file.getName());
            }
        }
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
		// Obtém o arquivo clicado
		String fileName = adapter.getItem(position);
		File file = new File(dir, fileName);
		
		// Exclui o arquivo
		if (!file.delete()) {
			throw new RuntimeException("O arquivo não pode ser excluído");
		}
		
		// Atualiza a lista
		refreshList();
		
		return true;
	}
}
