package br.com.softblue.exercicio;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;

public class EditFileActivity extends AppCompatActivity {
	
	private EditText edtFile;
	private File file;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_editfile);
		
		// Habilita a up navigation
		if (getActionBar() != null) {
			getActionBar().setDisplayHomeAsUpEnabled(true);
		}
		
		edtFile = findViewById(R.id.edt_file);
		
		file = (File) getIntent().getSerializableExtra("file");
		
		if (file != null) {
			// Se file existe, significa que é uma edição. Carrega os dados do arquivo na tela
			String fileContent = FileUtils.getFileAsString(file);
			edtFile.setText(fileContent);
		}
	}
	
	public void cancelar(View view) {
		// Cancela a operação
		setResult(RESULT_CANCELED);
		finish();
	}
	
	public void gravar(View view) {
		final String fileContent = edtFile.getText().toString();
		
		if (file == null) {
			// Se o arquivo não existe, abre o dialog solicitando o nome do arquivo
			FileNameDialog.show(getSupportFragmentManager(), new FileNameDialog.OnFileNameSetListener() {
				@Override
				public void onFileNameSet(String fileName) {
					// Obtém o nome escolhido pelo usuário e salva o conteúdo no arquivo
					File dir = (File) getIntent().getSerializableExtra("dir");
					file = new File(dir, fileName);
					saveContentToFileAndFinish(fileContent);
				}
			});
		
		} else {
			// Se o arquivo já existe, sobrescreve o conteúdo
			saveContentToFileAndFinish(fileContent);
		}
	}
	
	// Grava o conteúdo no arquivo e finaliza a activity
	private void saveContentToFileAndFinish(String content) {
		FileUtils.writeStringToFile(content, file);
		setResult(RESULT_OK);
		finish();
		Toast.makeText(this, "Arquivo gravado em " + file.getPath(), Toast.LENGTH_SHORT).show();
	}
}
