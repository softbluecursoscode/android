package br.com.softblue.exercicio;

import android.os.AsyncTask;
import android.widget.Button;
import android.widget.TextView;

public class ContadorTask extends AsyncTask<Integer, Integer, Void> {

	// Componentes, que precisam ser acessados pela task
	private TextView lblContador;
	private Button btnIniciar;

	// Construtor
	public ContadorTask(TextView lblContador, Button btnIniciar) {
		this.lblContador = lblContador;
		this.btnIniciar = btnIniciar;
	}

	@Override
	// Este método executa numa thread a parte
	protected Void doInBackground(Integer... params) {
		// é passado como parâmetro o valor inicial do contador, armazenado em max
		int max = params[0];

		// Executa um loop para ir decrementando o contador
		for (int contador = max; contador >= 0; contador--) {
			// Notifica o progresso, o que chama o método onProgressUpdate() com
			// o novo valor do contador
			publishProgress(contador);

			// Dorme 1s (1000ms) a cada decremento
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		return null;
	}

	@Override
	// Este método executa diretamente na UI thread, portanto pode alterar a
	// interface gráfica
	protected void onProgressUpdate(Integer... values) {
		// O valor atual do contador é passado como parâmetro
		int contador = values[0];

		// A TextView do contador é atualizada
		lblContador.setText(String.valueOf(contador));
	}

	@Override
	// Este método é executado antes do início da task
	protected void onPreExecute() {
		// Desabilita o botão 'Iniciar'
		btnIniciar.setEnabled(false);
	}

	@Override
	// Este método é executado após a finalização da task
	protected void onPostExecute(Void result) {
		// Habilita novamente o botão 'Iniciar'
		btnIniciar.setEnabled(true);
	}
}
