package br.com.softblue.exercicio;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ContadorActivity extends Activity {
	
	// Atributos para representar os componentes da tela
	private TextView txtContador;
	private Button btnIniciar;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Define o layout
		setContentView(R.layout.activity_contador);
		
		//Obtém os componentes e atribui aos atributos
		txtContador = (TextView) findViewById(R.id.txt_contador);
		btnIniciar = (Button) findViewById(R.id.btn_iniciar);
	}
	
	public void iniciar(View p) {
		//Ao clicar no botão, a contagem vai iniciar
		
		//Instancia a task, passando como parâmetro os componentes
		ContadorTask task = new ContadorTask(txtContador, btnIniciar);
		
		//Inicia a execução da task em segundo plano, indicando que o contador
		//inicia em 10
		task.execute(10);
	}
}
